# Handoff: PostDirect interface redesign ("Masthead" / Broadsheet)

## Overview
A full restyle of PostDirect — the internal tool that composes and mails real USPS letters via the Lob API. The redesign replaces the current dark-navy/card-based UI with **Broadsheet**: newsprint set for the web. Ink-black serif type on paper white, no boxes or cards, hierarchy from type scale and whitespace, thick-thin newspaper rules as masthead furniture, and two process accents used like spot color — **cyan (#0088b0) for everything interactive**, **magenta (#d6006c) reserved exclusively for moments where real postage is at stake** (live mode, undeliverable warnings, destructive actions).

The flow is unchanged: Login → 4-step wizard (Sender → Recipients → Content → Review) → Success, plus History. This is a restyle + copy polish, not a UX restructure.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, not production code to copy directly. The task is to **recreate these designs in the PostDirect codebase's existing environment** (vanilla JS + `public/index.html` + `public/css/app.css` + inline login page in `server.js`) using its established patterns. Do not ship the `.dc.html` file; it is a design-tool document.

- `PostDirect Redesign.dc.html` — open in a browser. The **top section ("Turn 2 · Masthead — the full set", badge 2a)** is the approved design: all 9 screens/states. Sections below it are earlier explorations — ignore them.
- `_ds/broadsheet-.../styles.css` — the design-system stylesheet. **This is the token source of truth** and is production-quality CSS: the cleanest implementation is to vendor this file into `public/css/` and build on its classes.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy are final. Recreate pixel-perfectly. All values below are exact; anything not listed is in `styles.css` as a `--token`.

## Design Tokens
Vendor `styles.css` (recommended) or port these into `app.css`:

- Ground: `--color-bg: #f3f2f2` (paper) · `--color-text: #201e1d` (ink)
- Interactive accent (cyan): `--color-accent: #0088b0`; hover `--color-accent-600`; long text on paper uses `--color-accent-700`
- Danger/live accent (magenta): `--color-accent-2: #d6006c`; hover `--color-accent-2-600`; text `--color-accent-2-700`
- Each role has a 100–900 OKLCH ramp in `styles.css` (`--color-neutral-*`, `--color-accent-*`, `--color-accent-2-*`). Tinted fills = 100–300; text on tints = 700–900.
- Muted ink is expressed as transparency of ink: 68% (body sub-copy), 60% (labels/meta), 55% (fine meta), 50% (done steps), 45% (footnotes), 38% (future steps). E.g. `color-mix(in srgb, var(--color-text) 68%, transparent)`.
- Type: **Source Serif 4 for everything** — headings, body, UI chrome. No sans-serif anywhere. Load: `https://fonts.googleapis.com/css2?family=Source+Serif+4:ital,opsz,wght@0,8..60,400..700;1,8..60,400&display=swap` (true italic required). Remove Inter entirely.
- Radius: `--radius-md: 2px` (near-square). Shadows: `--shadow-sm/md/lg` from styles.css.
- Spacing rhythm used in the mocks: section padding 56px; 45px below stepper; 26px row-gap / 40px column-gap in form grids; 55–60px between major blocks.
- Focus: `:focus-visible { outline: 2px solid var(--color-accent); outline-offset: 2px; }` (already in styles.css). No browser-default blue.

## Component classes (from styles.css — reuse, don't reinvent)
`.btn` + `.btn-primary` (solid cyan) / `.btn-secondary` / `.btn-ghost` / `.btn-block` · `.tag` + `.tag-accent` (cyan tint) / `.tag-accent-2` (magenta tint) / `.tag-neutral` / `.tag-outline` · `.field` + `label` + `.input` · `.seg` + `.seg-opt` (segmented radio) · `.table` (ledger) · `.elev-md` (letter sheet).

## Screens / Views (all in section 2a of the reference file)

### Shared: Masthead header (every screen after login)
- Container: page gutter 56px. Structure top-to-bottom: **3px solid ink rule** → header row (13px vertical padding) → **1px solid ink rule** (the thick-thin pair).
- Header row, flex, gap 30px: brand (margin-right auto) · "Compose" link · "History (n)" link · env tag · "Sign out".
- Brand: postage-stamp mark = 27×33px box, 1px solid ink, containing 21×27px box with 1px **dashed** `--color-neutral-400` border and "PD" 11px serif 600 in `--color-accent-700`; wordmark "PostDirect" 20px serif 600, letter-spacing -0.015em.
- Nav links 14px, no underline; active page = cyan + weight 600; inactive = ink. Count in parens at 55% ink.
- Env tag: Test = `.tag-neutral` "Proof press · Test"; Live = `.tag-accent-2` "Live · real postage".
- API-key rail (Compose + History only), 16px below rules: label "API KEY" 11px uppercase ls 0.08em 60% ink · password `.input` 300px wide, placeholder "test_… or live_…" · link "Lob dashboard →" 13px cyan.

### Shared: Stepper ("contents line")
Serif 14px, flex gap 30px, 45px margin below. Done: "01  Sender ✓" at 50% ink. Current: weight 600, the two-digit number in cyan ("**03**  Content"). Future: 38% ink. No circles, no progress bar.

### Shared: Page title block
h1 (styles.css scale) with editorial period: "The return address." / "The recipients." / "The letter." / "The final proof." / "Gone to press." / "The record." / "Sign in." Then sub-copy 15px, 68% ink, max-width 58ch. Content column max-width 800px; form grids max-width 680px.

### 1. Login (replaces inline page in server.js)
Paper background (no dark gradient). Masthead: rules + brand left, "PHYSICAL MAIL · USPS" 11px uppercase 55% ink right, no nav. Content max-width 460px: h1 "Sign in.", sub "PostDirect mails real letters. Operators only." Username + Password `.field`s (22px/34px below), `.btn-primary .btn-block` "Sign in", footer "SECURED ACCESS · SESSIONS EXPIRE AFTER 12 HOURS" 12px uppercase ls 0.08em 50% ink, 30px above.

### 2. Sender
Title "The return address." Sub: "Printed on the envelope and at the head of the letter. Undeliverable mail comes back here." Grid 2-col (26px/40px gap): Full name* / Firm; Address 1* and Address 2 span both cols; then 2fr/1fr/1fr: City* / State* / ZIP*. Required marker = plain asterisk in the label. Footer row: italic "Step one of four" 13px 45% ink left; `.btn-primary` "Continue to recipients →" right.

### 3. Recipients
Title "The recipients." Sub: "Everyone below receives the same letter, individually addressed and mailed." Each recipient = **no card**: h6 kicker "Recipient № 1" in `--color-accent-700` + ghost "Remove" (13px) on one baseline row, then the same address grid as Sender. 55px whitespace between recipients. Below: `.btn-secondary` "+ Add another recipient" + italic count "Two recipients" 13px 50% ink. Footer: ghost "← Sender" / primary "Continue to content →".

### 4. Content — Write
Title "The letter." Sub: "Write it here, or upload a print-ready PDF. What you set on this page is exactly what gets printed, folded and mailed." `.seg`: "Write the letter" (selected) / "Upload a PDF".
- **Ruled textarea** (signature element): no border, no box. 17px serif, line-height 34px, min-height 380px, ruled lines via `background-image: repeating-linear-gradient(transparent, transparent 33px, color-mix(in srgb, var(--color-text) 15%, transparent) 33px, ... 34px); background-attachment: local;` Caption below: "Printed on 8.5 × 11″ letter paper, set in a serif close to this one." 12px 55% ink.
- **Mailing options** (h6 "Mailing options", 55px above): grid 2-col. Mail class = seg First Class/Standard + helper 12px 55% ink "First Class arrives in 5–7 days and forwards with the recipient." Extra service = select (None / Certified Mail / Certified + Return Receipt / Registered Mail) + "Certified and Registered ride First Class. Fees apply." Use type = seg Operational/Marketing. Address placement = select (Top of first page / Insert blank address page). Send date = date input + "Blank mails immediately; schedule up to 180 days out." Description = text input, label "Description — internal memo", placeholder "Q4 invoice for Acme Corp".
- Checkboxes row (accent-color cyan, 15px): "Color printing" (checked) / "Double-sided" / "Reply envelope — adds a perforated first page".
- Footer: ghost "← Recipients" / primary "Continue to review →".

### 5. Content — Upload
Same page, seg on "Upload a PDF". Drop zone: **1px dashed `--color-neutral-400`**, padding 56px 32px, centered: "Drop a PDF on the press bed" 18px serif 600; "or browse for the file" 13.5px with cyan link; "Maximum 50 MB · 8.5 × 11″ with ½″ margins recommended" 12px 50% ink. Uploaded file row (20px vertical padding, 1px `--color-divider` bottom rule): PDF stamp 34×42px 1px solid ink with "PDF" 10px serif 600 · filename 15px serif 600 + "1.4 MB · 4 pages" 12.5px 55% ink · ghost "Remove". Italic note: "Lob accepts PDF only. The address block prints per your placement setting."

### 6. Review (shown in Live mode)
Header tag = `.tag-accent-2` "Live · real postage". Title "The final proof." Sub: "Check everything below — this is exactly what goes to press and into the mail stream."
- h6 "From" + address block 14.5px/1.7, name serif bold.
- h6 "Recipients — two", 2-col grid 40px gap. Each: name serif 600 15px + deliverability tag on baseline row; address 13.5px/1.65 at 75% ink. Deliverable: `.tag-accent` + line "USPS suggests **456 OAK AVE STE 2, 62701-1904** · Use suggested" (12.5px, bold part full ink, cyan link). Undeliverable: `.tag-accent-2` + "USPS could not match this address. Check the street number and ZIP." in `--color-accent-2-700`.
- Acknowledgment (only when undeliverables exist, gates Send): checkbox accent-color magenta + 13.5px `--color-accent-2-700`: "One address is undeliverable according to USPS. Mail it anyway — I understand the postage may be wasted."
- h6 "The letter as it prints" + **letter sheet**: `.elev-md`, background `--color-neutral-100`, padding 44px 50px, max-width 640px. Top row: sender block 12px 62% ink left, italic date right. Body 15px/1.9 pre-wrap serif. Footer: "PAGE 1 OF 1" / "8.5 × 11″ · LETTER" 11px uppercase 45% ink.
- Summary line 13px 60% ink: "Two recipients · First Class · Certified Mail · Color · Single-sided · **Live — real postage**" (bold part `--color-accent-2-700>`).
- Footer: ghost "← Content" / **Send button**: `.btn-primary` overridden to `background: var(--color-accent-2); border-color: var(--color-accent-2)`, hover `--color-accent-2-600`, label "Send two letters" (count interpolated). In Test mode the button stays cyan and the header tag stays neutral.

### 7. Success
h6 kicker "Accepted · 2 of 2" in `--color-accent-700`. Title "Gone to press." Sub: "Both letters were accepted and queued for USPS First Class delivery. Tracking numbers appear in the record once each letter enters the mail stream." `.table` (max-width 720px): Recipient (serif 600 15px) / Letter № (12.5px `--color-neutral-700`) / Status (`.tag-accent` "Queued"). Buttons: primary "View the record →" + secondary "Send another letter".

### 8. History
Title row: "The record." left; "Updated 2 minutes ago" 12.5px 55% ink + `.btn-secondary` "Refresh" right. Sub: "Every letter on this account — live USPS tracking, and a court-ready proof package for each one."
- **Ledger `.table`**, columns: Recipient (34%: name serif 600 15px over address 12px 55% ink) / Letter № (short id, 12.5px `--color-neutral-700`) / Service / Mailed / Status / actions (right-aligned).
- Status tags: Delivered `.tag-accent` · In transit `.tag-outline` · Processing `.tag-neutral` · failed states `.tag-accent-2`. Actions: ghost "Export proof"; Processing rows also ghost "Cancel" colored `--color-accent-2-700`.
- Expanded detail row (colspan, 1px divider bottom): grid 180px + 1fr — "TRACKING" label 11px uppercase + cyan tracking-number link; right, timeline of events 13.5px, 9px apart: latest = weight 600 with filled cyan duotone dot (13px SVG: r100 circle at 0.2 opacity + r48 solid, fill #0088b0), earlier = 65% ink with outline-only dot; timestamps right-aligned 12px 55% ink.
- Rows awaiting tracking show "Awaiting tracking number" via `.tag-outline` + helper text instead of the timeline.

### 9. History — Empty
Title "The record." + italic "Nothing has gone to press yet." 15px 60% ink + sub "Letters you send will appear here with live USPS tracking and an exportable proof package." (max 48ch) + primary "Compose the first letter →".

## Interactions & Behavior
- Hover: buttons/links shift one ramp step (cyan → `--color-accent-600`; magenta send → `--color-accent-2-600`); ghost/outline get a light accent tint. Pressed = one step further. All in styles.css.
- Keyboard focus: 2px cyan `:focus-visible` ring everywhere.
- Wizard: Continue disabled until required fields valid (disabled = 45% opacity, in styles.css). Back never destroys entered data.
- Recipients: Add appends a block (№ increments); Remove deletes it; count line updates ("Two recipients").
- Content: seg toggles Write/Upload panes, both preserved in state.
- Review: address verification runs via Lob on entry — per-recipient tag + suggestion; "Use suggested" swaps the address in place. Send blocked while any undeliverable exists and the acknowledgment is unchecked. During send, button disables and shows "Sending 1 of 2…".
- Live vs Test drives: header tag, send-button color, summary-line warning. Detect from API key prefix (`live_` / `test_`).
- History: refresh re-polls Lob; expanded tracking loads per letter.
- No new animations; keep existing transitions subtle (~150ms ease on hover states).

## State Management
Unchanged from current app.js: wizard step index; sender object; recipients array; content mode + letter text / uploaded file; mailing options; API key (localStorage); verification results per recipient; send progress; history list + per-letter tracking events. Only render output changes.

## Implementation map (PostDirect repo)
1. `public/css/app.css` — replace wholesale: vendor `styles.css` as the base layer, then a small page layer for the layout patterns above (masthead rules, stepper line, ruled textarea, letter sheet, form grids).
2. `public/index.html` — swap font links (drop Inter; Source Serif 4 w/ italic); restructure: header → masthead (thick-thin rules), stepper circles/bar → contents line, recipient cards → kicker + grid, review cards → open blocks, history card list → `<table class="table">`; update all copy strings to the ones above.
3. `server.js` — replace the inline login page (markup + embedded CSS) with screen 1.
4. `public/js/*.js` — update render functions that emit HTML: history renderer now outputs table rows + expandable detail row; status→tag-class map; stepper active-state logic; env tag text; button labels with counts ("Send two letters"). Grep for old class names (`.card`, `.badge`, `.step`, etc.).
5. Delete dead styles: dark header gradients, gold/amber accents (#f4a92b), Inter references, card shadows.

## Assets
No raster assets. Brand mark is pure HTML/CSS (stamp boxes above). Font: Source Serif 4 (Google Fonts). Icons if needed: Phosphor duotone (https://phosphoricons.com) — the mocks use only two inline SVG dots for the tracking timeline (spec above).

## Files in this bundle
- `PostDirect Redesign.dc.html` — design reference; **section 2a (top) is the approved design**; lower sections are explorations.
- `support.js`, `_ds/broadsheet-acab932b-6f1f-4c8d-948a-178ec182be48/{styles.css,_ds_bundle.js}` — runtime for opening the reference file locally. `styles.css` doubles as the token/component source of truth.
